package com.ms.ci.hydra.data.pipeline.shutdownhook

trait ShutDownHooks {

}
