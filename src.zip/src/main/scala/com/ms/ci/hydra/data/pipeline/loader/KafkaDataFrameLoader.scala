package com.ms.ci.hydra.data.pipeline.loader

import com.ms.ci.hydra.data.pipeline.SparkJobLogging
import org.apache.spark.sql.{DataFrame, SparkSession}

class KafkaDataFrameLoader(params: Map[String,String]) extends  DataFrameLoader with  SparkJobLogging {


  override def loadDataframe()(implicit spark: SparkSession): DataFrame = {
   val df:DataFrame = spark.read
     .format("kafka")
     .option("kafka.bootstrap.servers", s"${params.get("broker").get}")
     .option("kafka.security.protocol", s"${params.get("protocol").get}")
     .option("kafka.group.id", s"${params.get("groupId").get}")
     .option("kafka.security.protocol", s"${params.get("protocol").get}")
     .option("kafka.sasl.mechanism", s"${params.get("saslMechanism").get}")
     .option("kafka.sasl.jaas.config", s"${params.get("jaasConfig").get}")
     .option("subscribe", s"${params.get("topic").get}")
     .option("startingOffsets", s"${params.get("startingOffsets").get}")
     .option("endingOffsets", s"${params.get("endingOffsets").get}")
     .option("includeHeaders", s"${params.get("isHeaderIncluded").get}")
     .option("failOnDataLoss", "false")
     .load()

    val finalDf = getWithoutHeader(params.get("headers").get, df)
    finalDf
  }

  def getWithoutHeader(is_header: String, df: DataFrame): DataFrame = {
    val isHeader = is_header.toBoolean
    isHeader match {
      case true => df.select("value", "topic", "partition", "offset", "timestamp", "headers")
      case _ => df.select("value", "topic", "partition", "offset", "timestamp")
    }
  }

}
