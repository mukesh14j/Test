package com.ms.ci.hydra.data.pipeline.loader
import com.ms.ci.hydra.data.pipeline.SparkJobLogging
import org.apache.hadoop.fs.Path
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.io.File

class CSVDataLoader(params: Map[String,String]) extends  DataFrameLoader with  SparkJobLogging {

  override def loadDataframe() (implicit spark: SparkSession): DataFrame = {
    val destPath = params.get("file_location").get
    val df  = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(params.get("file_location").get+"/delta_data.csv")
    val latestFile = getLatestFile(destPath)

    logger.info(s"latestFile is ${latestFile}")
    logger.info(s"latest df is ${df.show(20)}")
    df
  }

  def getLatestFile(dirPath: String, ext: String = "csv"): File ={
    val dir = new File(dirPath)
    val files = dir.listFiles()
    if (files == null || files.length == 0) { return null }

    var lastModifiedFile = files.headOption.get
    for( a <- 0 to files.length){
      if (lastModifiedFile.lastModified() < files(a).lastModified()) {
        lastModifiedFile = files(a)  } }
    lastModifiedFile;
  }
}
