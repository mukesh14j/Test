package com.ms.ci.hydra.data.pipeline.postprocessor

trait PostProcessor {

}
