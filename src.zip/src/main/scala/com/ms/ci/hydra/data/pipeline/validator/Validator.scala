package com.ms.ci.hydra.data.pipeline.validator

trait Validator[T] {

}
