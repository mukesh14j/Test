package com.ms.ci.hydra.data.pipeline.loader
import org.apache.spark.sql.{DataFrame, SparkSession}

trait DataFrameLoader {

  def loadDataframe() (implicit spark: SparkSession): DataFrame

}
