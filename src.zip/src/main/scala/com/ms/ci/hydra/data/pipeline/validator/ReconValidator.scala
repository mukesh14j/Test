package com.ms.ci.hydra.data.pipeline.validator

import com.ms.ci.hydra.data.pipeline.SparkJobLogging

class ReconValidator(params: Map[String,String]) extends Validator[Unit] with  SparkJobLogging {

}
