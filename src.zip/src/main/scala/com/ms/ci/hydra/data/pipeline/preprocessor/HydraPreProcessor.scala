package com.ms.ci.hydra.data.pipeline.preprocessor

import com.ms.ci.hydra.data.pipeline.SparkJobLogging
import org.apache.spark.sql.SparkSession

class HydraPreProcessor(params: Map[String,String]) extends PreProcessor[Unit] with SparkJobLogging{

  override def run()(implicit builder: SparkSession.Builder): Unit = {
    logger.info(s"Running HydraPreProcessor with params $params")

    val ENDPOINT: String = "spark.hadoop.fs.s3a.endpoint"
    val ACCESS_KEY: String = "spark.hadoop.fs.s3a.access.key"
    val SECRET_KEY: String = "spark.hadoop.fs.s3a.secret.key"
    val default = false
    val bucket = params.get("bucketName").get

    val bucketEndpoint = if (default) ENDPOINT else "spark.hadoop.fs.s3a.endpoint." + bucket + ".endpoint"
    val bucketAccessKey =  if (default) ACCESS_KEY else "spark.hadoop.fs.s3a.endpoint." + bucket + ".access.key"
    val bucketSecretKey =  if (default) SECRET_KEY else "spark.hadoop.fs.s3a.endpoint." + bucket + ".secret.key"

    if(params.get("is_s3_enabled").get.toBoolean) {
      builder.config(bucketEndpoint, params.get("endpoint").get)
      builder.config(bucketAccessKey, params.get("accessKey").get)
      builder.config(bucketSecretKey, params.get("secretKey").get)
    }

    logger.info(s"Done in PreProcessor")
    builder.enableHiveSupport().getOrCreate()

  }


}
