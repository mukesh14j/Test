package com.ms.ci.hydra.data.pipeline.utils

import com.ms.ci.hydra.data.pipeline.SparkJobLogging

import scala.collection.mutable.ListBuffer


case class Attribute(attribute: String, matchType: String)
case class Rules(ruleName:String, ruleDef: List[Attribute])

object HydraRule extends  SparkJobLogging{

  val exactMatch = "EXACT"
  val fuzzyMatch = "FUZZY"

  def getRuleSet(): ListBuffer[Rules]={

    val rule = new ListBuffer[Rules]()
    rule += Rules("Rule1", List(Attribute("CITY_NAME", exactMatch), Attribute("COUNTRY_NAME", exactMatch),
      Attribute("IDN_DOC_TYPE", exactMatch),Attribute("Party_Type", exactMatch),
      Attribute("MATCH_NAME", fuzzyMatch)))

    rule += Rules("Rule2", List(Attribute("CITY_NAME", exactMatch), Attribute("COUNTRY_NAME", exactMatch),
      Attribute("IDN_DOC_TYPE", exactMatch),Attribute("Party_Type", exactMatch),
      Attribute("ADDRESS_LINE_2", fuzzyMatch)))

    rule
  }

}
