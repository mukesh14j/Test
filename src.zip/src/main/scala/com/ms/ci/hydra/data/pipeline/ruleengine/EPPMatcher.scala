package com.ms.ci.hydra.data.pipeline.ruleengine

import com.ms.ci.hydra.data.pipeline.algo.SimilarityFunctions

import com.ms.ci.hydra.data.pipeline.SparkJobLogging
import com.ms.ci.hydra.data.pipeline.utils.{Attribute, HydraRule, Rules}
import org.apache.spark.sql.functions.{col, hash}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.collection.mutable.ListBuffer

class EPPMatcher(params: Map[String,String]) extends RuleEngine with SparkJobLogging {

  override def ruleRunner(dataFrame: DataFrame)(implicit spark: SparkSession): DataFrame = {
    logger.info(s"latest df is ${dataFrame.show(20)}")
    val basePath = params.get("file_location").get
    val baseDF = spark.read.format("csv").option("header", "true").option("inferSchema", "true").load(params.get("file_location").get + "/base_data.csv")
    val rule = HydraRule.getRuleSet()
    val tuple_match_cols = getRuleAttribute(rule)
    logger.info(s"exactList is  ${tuple_match_cols._1}")
    val tupleDF = addMd5Hash(baseDF, dataFrame, tuple_match_cols._1)
    val match_df = computeRules(rule, tupleDF._1, tupleDF._2)
    logger.info(s"match_df data frame is ${match_df.show(20)}")

    null
  }

  def getRuleAttribute(rules: ListBuffer[Rules]): (Set[String], Set[String]) = {
    var exactList = Set[String]()
    var fuzzySet = Set[String]()
    for (eachRule <- rules) {
      exactList = eachRule.ruleDef.filter(attr => attr.matchType == "EXACT").map(attr => attr.attribute).toSet ++ exactList
      fuzzySet = eachRule.ruleDef.filter(attr => attr.matchType == "FUZZY").map(attr => attr.attribute).toSet ++ fuzzySet
    }
    (exactList, fuzzySet)
  }

  def addMd5Hash(baseDF: DataFrame, deltaDF: DataFrame, attrList: Set[String]): (DataFrame, DataFrame) = {
    var base_hash_df = baseDF
    var delta_hash_df = deltaDF
    for (eachAttr <- attrList) {
      base_hash_df = base_hash_df.withColumn(eachAttr + "_hash", hash(col(eachAttr)))
      delta_hash_df = delta_hash_df.withColumn(eachAttr + "_hash", hash(col(eachAttr)))
    }
    (base_hash_df, delta_hash_df)
  }

  def computeRules(rules: ListBuffer[Rules], baseDF: DataFrame, deltaDF: DataFrame): DataFrame = {
    var main_df = baseDF
    var exactList = List[String]()
    var fuzzySet = List[String]()
    for (eachRule <- rules) {
      exactList = eachRule.ruleDef.filter(attr => attr.matchType == "EXACT").map(attr => attr.attribute + "_hash")
      fuzzySet = eachRule.ruleDef.filter(attr => attr.matchType == "FUZZY").map(attr => attr.attribute)
      for (eachFuzzy <- fuzzySet) {
        val colName = "src_df_" + eachFuzzy
        main_df = baseDF.withColumn(colName, col(eachFuzzy))
      }
    }
    val match_df = deltaDF.alias("deltaDF").join(main_df.alias("main_df"), exactList, "inner")
      .select(deltaDF("*"), main_df.colRegex("`(src_df_)+?.+`"))

    val newDF = computeFuzzy(match_df, fuzzySet, 0.85)
    newDF
  }

  def computeFuzzy(match_df: DataFrame, fuzzyList: List[String], threshold: Double): DataFrame = {
    for (eachFuzzy <- fuzzyList) {
      val col_name = "src_df_" + eachFuzzy
      var newDF = match_df.withColumn("similarity_score", SimilarityFunctions.jaro_winkler(col(eachFuzzy), col(col_name)))
      logger.info(s"shows with similarity score for col $eachFuzzy for DF is ${newDF.show()}")
      newDF = newDF.filter(newDF("similarity_score") > threshold)
      newDF = newDF.drop(col("similarity_score"))
      newDF
    }
    null
  }

}
