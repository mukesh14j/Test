package com.ms.ci.hydra.data.pipeline.postprocessor

import com.ms.ci.hydra.data.pipeline.SparkJobLogging

class HydraPostProcessor(params: Map[String,String]) extends PostProcessor with SparkJobLogging{

}
