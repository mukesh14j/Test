from geopy.geocoders import Nominatim
import pandas as pd


geolocator = Nominatim(user_agent="")
from geopy.geocoders import GoogleV3
geolocator = GoogleV3(api_key='YYAJSJDBCDDDTDKDYTT')

def extract_clean_address(address):
    try:
        location = geolocator.geocode(address)
        return location.address
    except:
        return ''

def extract_lat_long(address):
    try:
        location = geolocator.geocode(address)
        return [location.latitude, location.longitude]
    except:
        return ''

if __name__ == '__main__':
    messy_address = pd.csv("base_data.csv")
    messy_address['clean address'] = messy_address.apply(lambda x: extract_clean_address(x['Raw Address']) , axis =1 )
    messy_address['lat_long'] = messy_address.apply(lambda x: extract_lat_long(x['Raw Address']), axis=1)
    messy_address['latitude'] = messy_address.apply(lambda x: x['lat_long'][0] if x['lat_long'] != '' else '', axis=1)
    messy_address['longitude'] = messy_address.apply(lambda x: x['lat_long'][1] if x['lat_long'] != '' else '', axis=1)
    messy_address.drop(columns=['lat_long'], inplace=True)